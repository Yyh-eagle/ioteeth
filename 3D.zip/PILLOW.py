import os

import cv2
import numpy as np
import glob
import PIL.ExifTags
import PIL.Image
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D


#####################################函数库####################################
#对图像效果进行增强
def enhance_image(img, contrast_factor=1.5, blur_kernel_size=(5, 5), sigma=0):

    original_image = img # 读取图片
    gray_image = cv2.cvtColor(original_image, cv2.COLOR_BGR2GRAY)# 转换为灰度图
    enhanced_image = cv2.convertScaleAbs(gray_image, alpha=contrast_factor, beta=0)# 增强对比度
    blurred_image = cv2.GaussianBlur(enhanced_image, blur_kernel_size, sigma)# 高斯滤波

    return blurred_image

#进行特征提取
def SIFTExtract(img):
    # 构建图像金字塔
    pyramid_levels = 3
    for level in range(pyramid_levels):
        print("金字塔第", level, "层")
        scaled_img = cv2.pyrDown(img)

        sift = cv2.SIFT_create()  # 创建sift对象
        # 检测两幅图像的特征描述子和关键点
        keypoint, descriptor = sift.detectAndCompute(scaled_img, None)
        # 将图像用于下一级
        img = scaled_img


        return keypoint,descriptor


#判断R矩阵是否符合正交规则
def checkValidRot(R):
    check =np.allclose(np.dot(R.T,R),np.eye(3))
    return check

#特征矩阵的计算
def EssentialMatrix(matches,data_K):
    good = []
    points1 = []
    points2 = []
    # 对得到的特征角点进行遍历，
    for i, (m, n) in enumerate(matches):

        if m.distance < 0.7 * n.distance:  # 两个特征点是否足够接近的判据
            good.append(m)
            points1.append(keypoint1[m.queryIdx].pt)
            points2.append(keypoint2[m.trainIdx].pt)
    points1 = np.float32(points1)
    points2 = np.float32(points2)

    # 计算两幅图像之间的基础矩阵
    if len(good)== 0: return 0
    F, mask = cv2.findFundamentalMat(points1, points2, cv2.RANSAC, ransacReprojThreshold=1.5)  # F是基础矩阵，mask是用来标识离群点
    if mask is None: continue;
    # 将离群点去掉
    points1 = points1[mask.ravel() == 1]
    points2 = points2[mask.ravel() == 1]

    print("基础矩阵F", F)
    print("正在矩阵与投影计算")

    mtx_loaded = data_K['mtx']
    K = np.array(mtx_loaded)

    # 本证矩阵的计算
    E = K.T * F * K

    # SVD分解
    W = np.array([[0, -1, 0], [1, 0, 0], [0, 0, 1]])
    U, S, V = np.linalg.svd(E)

    # 计算旋转矩阵
    R = U * W * V
    # 计算平移向量
    t = [U[0, 2], U[1, 2], U[2, 2]]

    return F,E,R,t

#投影矩阵的计算
def ProjectionMatrix(R,t):

    P1 = [[R[0, 0], R[0, 1], R[0, 2], t[0]], [R[1, 0], R[1, 1], R[1, 2], t[1]], [R[2, 0], R[2, 1], R[2, 2], t[2]]]
    P = [[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, 0]]

    return P,P1
#窗口搜索
def window_search(ReferenceImage,CurrentImage,InitialPosition,WindowSize,DistanceThreshold):
    h,w = ReferenceImage.shape[:,2]#获取参考图的长宽
    x,y = InitialPosition#初始窗口搜索的位置

    #定义搜索窗口范围
    SearchWindow = CurrentImage[max(0,y-WindowSize):min(h,y+WindowSize),
                                max(0,x-WindowSize):min(w,x+WindowSize)]

    border_size = WindowSize  # 可以根据实际情况调整
    SearchWindow = cv2.copyMakeBorder(SearchWindow,border_size,border_size,border_size,border_size,cv2.BORDER_CONSTANT, value=0 )

    BestMatch =None
    min_mse =float('inf')

    for dy in range(-WindowSize,WindowSize+1):
        for dx in range(-WindowSize,WindowSize+1):
            mse = np.mean((ReferenceImage-SearchWindow[y+dy:y+dy+h,x+dx:x+dx+w])**2)

            #更新最佳匹配
            if mse < min_mse and mse < DistanceThreshold:
                min_mse = mse
            BestMatch = (x+dx,y+dy)

    return BestMatch

# initial_position = (100, 100)
# window_size = 20
# DistanceThreshold =100



#########################初始化#####################################

# 初始化点云坐标
pointCloudX = []
pointCloudY = []
pointCloudZ = []


###########################图片预处理######################################
folder_path ="/home/pi/cvcv/result/"
image_files =[filename for filename in os.listdir(folder_path)if filename.endswith('.jpg')]

for i in range(0,len(image_files),2):
    #构建完整的文件路径
    image_path_1 = os.path.join(folder_path,image_files[i])
    image_path_2 = os.path.join(folder_path,image_files[i+1])
    #使用opencv打开图像
    img1 =cv2.imread(image_path_1)
    img2 =cv2.imread(image_path_2)

    img1 = enhance_image(img1)
    img2 = enhance_image(img2)
    print("打开成功，第",i,i+1,"组,开始特征点匹配")

    ##########################SIFT特征点匹配###################################
    # 初始化列表，准备用循环填充列表元素
    good = []
    points1 = []
    points2 = []

    #得到检测特征带点
    keypoint1,descriptor1 =SIFTExtract(img1)
    keypoint2,descriptor2 =SIFTExtract(img2)


    # 用匹配器进行匹配
    FLANN_INDEX_KDTREE = 0  # 定义k-d树索引的类型
    index_params = dict(algorithm=FLANN_INDEX_KDTREE, trees=5)  # 创建了一个字典，其中包含了建立FLANN索引所需要的参数
    search_params = dict(checks=50)  # 创建了一个字典，用于搜索近邻的参数
    flann = cv2.FlannBasedMatcher(index_params, search_params)
    bf = cv2.BFMatcher()
    matches = bf.knnMatch(descriptor1, descriptor2, k=2)  # 最佳匹配 matches是个列表，里面储存的是啥
    # print("matches", matches)

    # 对得到的特征角点进行遍历，
    for i, (m, n) in enumerate(matches):

        if m.distance < 0.7 * n.distance:  # 两个特征点是否足够接近的判据
            good.append(m)
            points1.append(keypoint1[m.queryIdx].pt)
            points2.append(keypoint2[m.trainIdx].pt)

    if (EssentialMatrix(matches,"calibration.npz")==0): exit(0)
    #计算本证矩阵
    F,E,R,t = EssentialMatrix(matches,"calibration.npz")
    #计算投影矩阵
    P,P1 =ProjectionMatrix(R,t)

    ##################################有效特征点三角化############################

    points1 = np.array(points1)
    points2 = np.array(points2)
    points4D = cv2.triangulatePoints(P,P1,points1.T,points2.T)
    points3D = cv2.convertPointsToHomogeneous(points4D.T)

    X,Y,Z = points3D.squeeze()

pointCloudX = np.array(X)
pointCloudY = np.array(Y)
pointCloudZ = np.array(Z)

print("###############",len(pointCloudX))

fig =plt.figure()
ax =fig.add_subplot(111, projection='3d')

# 绘制三维点云
ax.scatter(pointCloudX, pointCloudY, pointCloudZ, c='b', marker='o',s=5)

# 设置坐标轴标签
ax.set_xlabel('X')
ax.set_ylabel('Y')
ax.set_zlabel('Z')

# 显示图形
plt.show()